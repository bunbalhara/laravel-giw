<div>Hi, <?php echo e($name); ?></div>
<h4>Thank you to visit GIW platform</h4>
<p>Here is your calculation!</p>
<table style="width: 100%; table-layout: auto; text-align: center; border-collapse: collapse">
    <caption style="font-size: 18px">Table 1</caption>
    <thead>
    <tr>
        <th style="border: solid 1px black; vertical-align: bottom; font-size: 20px" rowspan="2">Window Properties</th>
        <th style="border: solid 1px black; font-size: 20px" colspan="4">Ultimate Limit for Window to Wall Ratio</th>
    </tr>
    <tr>
        <th style="border: solid 1px black">North</th>
        <th style="border: solid 1px black">South</th>
        <th style="border: solid 1px black">East</th>
        <th style="border: solid 1px black">West</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="border: solid 1px black">
                <?php echo e($item->property); ?>

            </td>
            <td style="border: solid 1px black"><?php echo e($item->output->north); ?>%</td>
            <td style="border: solid 1px black"><?php echo e($item->output->south); ?>%</td>
            <td style="border: solid 1px black"><?php echo e($item->output->east); ?>%</td>
            <td style="border: solid 1px black"><?php echo e($item->output->west); ?>%</td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php /**PATH E:\Working\Laravel\2021-01-11-giw.com.au\giw\resources\views/mail/template1.blade.php ENDPATH**/ ?>