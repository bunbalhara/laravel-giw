@extends('layouts.front')
@section('styles')
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="{{asset('assets/css/front/home.css?'.time())}}"  rel="stylesheet" >
@endsection
@section('content')
    <div class="area-1 nectar-video-wrap position-loaded" data-bg-alignment="" style="opacity: 1; width: 1004px; height: 100%;">
        <div class="nectar-video-inner"><video class="nectar-video-bg" width="1800" height="700" preload="auto" loop="" autoplay="" muted="" playsinline="" style="visibility: visible; width: 1636px; height: 920px; opacity: 1;">
                <source src="https://giw.com.au/wp-content/uploads/2020/05/giw_home-hero-video-1080.webm?x81410" type="video/webm">
                <source src="https://giw.com.au/wp-content/uploads/2020/05/giw_home-hero-video-1080.mp4" type="video/mp4">
            </video></div>
    </div>
    <div class="row_col_wrap_12 col span_12 light center" style="min-height: 100vh; display: flex; justify-content: center; align-items: center;">
        <div class="area-1 user-info-container">
            <div class="title">GIW WINDOW TO WALL RATIO CALCULATOR</div>
            <div class="description">
                To assist architects and designers in early facade studies GIW have developed this free to use calculator which will offer indicative
                window to wall ratios as assessed under NCC 2019 Part J1.<br/>
                For more detailed assessment prior to development application please contact our office
                <a href="https://giw.com.au/contact/">here</a>
            </div>
            <div class="form-group">
                <div class="label">Full Name</div>
                <input name="name" placeholder="Enter your full name" class="form-control full-name">
            </div>
            <div class="form-group">
                <div class="label">Email</div>
                <input name="email" placeholder="Enter your email" class="form-control email-address">
            </div>
            <button class="submit-name-email" disabled>Continue</button>
        </div>
        <div class="area-2 calculation-form" hidden>
            <div class="form-group">
                <div class="label">Climate Zone</div>
                <select class="climate-zone select-box">
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                    <option>6</option>
                    <option>7</option>
                    <option>8</option>
                </select>
            </div>
            <div class="form-group">
                <div class="label">Building Classification</div>
                <select class="building-classification select-box">
                    <option>Class 5</option>
                    <option>Class 6</option>
                    <option>Class 7</option>
                    <option>Class 8</option>
                    <option>Class 9a Ward</option>
                    <option>Class 9a Other</option>
                    <option>Class 9b</option>
                    <option>Class 9c</option>
                </select>
            </div>
            <fieldset>
                <legend>Window Configuration</legend>
                <div class="form-group">
                    <div class="label">Window Properties</div>
                    <select class="window-properties select-box">
                        <option value="0" selected>Single Glazed, Clear</option>
                        <option value="1">Single Glazed, Low-E Clear</option>
                        <option value="2">Double Glazed, Clear</option>
                        <option value="3">Double Glazed, Low-E Clear</option>
                        <option value="4">Double Glazed, Tinted</option>
                        <option value="5">Double Glazed, Low-E Tinted</option>
                        <option value="6">Thermally Broken, Double Glazed, Low-E Clear</option>
                        <option value="7">Thermally Broken, Double Glazed, Low-E tinted</option>
                    </select>
                </div>
                <div class="form-group">
                    <div class="label">Total System U-value</div>
                    <input value="6.3" class="total-system-u-value input-box"/>
                </div>
                <div class="form-group">
                    <div class="label">Total System SHGC</div>
                    <input value="0.65" class="total-system-shgc input-box"/>
                </div>
            </fieldset>

            <table>
                <thead>
                <tr>
                    <th>Shading</th>
                    <th>Projection</th>
                    <th>W (window width)</th>
                    <th>H (window height)</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>North</td>
                    <td><input class="input-box north_projection" type="number"/></td>
                    <td><input class="input-box north_w" type="number"/></td>
                    <td><input class="input-box north_h" type="number"/></td>
                </tr>
                <tr>
                    <td>East</td>
                    <td><input class="input-box east_projection" type="number"/></td>
                    <td><input class="input-box east_w" type="number"/></td>
                    <td><input class="input-box east_h" type="number"/></td>
                </tr>
                <tr>
                    <td>South</td>
                    <td><input class="input-box south_projection" type="number"/></td>
                    <td><input class="input-box south_w" type="number"/></td>
                    <td><input class="input-box south_h" type="number"/></td>
                </tr>
                <tr>
                    <td>West</td>
                    <td><input class="input-box west_projection" type="number"/></td>
                    <td><input class="input-box west_w" type="number"/></td>
                    <td><input class="input-box west_h" type="number"/></td>
                </tr>
                </tbody>
            </table>

            <fieldset>
                <legend>Ultimate Limit for Window to Wal Ratio</legend>
                <div class="form-group">
                    <div class="label">North</div>
                    <input class="input-box" readonly/>
                </div>
                <div class="form-group">
                    <div class="label">East</div>
                    <input class="input-box" readonly/>
                </div>
                <div class="form-group">
                    <div class="label">South</div>
                    <input class="input-box" readonly/>
                </div>
                <div class="form-group">
                    <div class="label">West</div>
                    <input class="input-box" readonly/>
                </div>
            </fieldset>
            <div class="form-group">
                <button disabled> Submit </button>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        $(document).ready(function () {
            $('.area-2').hide();
            $(document).on('change keyup','.email-address,.full-name', function (){
                let email = $('.email-address').val();
                let fullName = $('.full-name').val();
                let enabled = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(email) && fullName
                $('.submit-name-email').prop('disabled', !enabled);
            })

            let email = '';
            let fullName = '';

            $('.submit-name-email').click(function (){
                email = $('.email-address').val();
                fullName = $('.full-name').val();

                let formData = new FormData();
                $('.area-1').hide();
                $('.area-2').show();
                {{--$.ajax({--}}
                {{--    headers: {--}}
                {{--        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')--}}
                {{--    },--}}
                {{--    type:'post',--}}
                {{--    url:'{{route('user.add')}}',--}}
                {{--    data: formData,--}}
                {{--    cache: false,--}}
                {{--    processData: false,--}}
                {{--    contentType: false,--}}
                {{--    success:res=>{--}}
                {{--        if(res.status){--}}

                {{--        }--}}
                {{--    },--}}
                {{--    error:err=>console.log(err)--}}
                {{--})--}}
            })

            let climateZone = 0, buildingClassification = 0, windowProperty = 0, totalSystemUValue = 0, totalSystemSHGC = 0;
            let northProjection = 0, northW = 0, northH = 0, northG = 0;
            let eastProjection = 0, eastW = 0, eastH = 0, eastG = 0;
            let southProjection = 0, southW = 0, southH = 0, southG = 0;
            let westProjection = 0, westW = 0, westH = 0, westG = 0;

            let northUValLimit = 0, northSHGCLimit = 0, northUltimateLimit = 0;
            let eastUValLimit = 0, eastSHGCLimit = 0, eastUltimateLimit = 0;
            let southUValLimit = 0, southSHGCLimit = 0, southUltimateLimit = 0;
            let westUValLimit = 0, westSHGCLimit = 0, westUltimateLimit = 0;

            let sAn = 0, sAe = 0, sAs = 0, sAw = 0;
            let sN = 0, sE = 0, sS = 0, sW = 0;
            let uAve = 0, uWal = 0;

            let windowsProperties = [
                [6.3, 0.65],
                [4.6,0.55],
                [3.7,0.55],
                [3.7,0.6],
                [3.2,0.5],
                [3.7,0.4],
                [3.2,0.3],
                [2.5,0.5],
                [2.5,0.28]
            ]

            $('.window-properties').change(function () {
                let index = $(this).val();
                $('.total-system-u-value').val(windowsProperties[index][0])
                $('.total-system-shgc').val(windowsProperties[index][1])
            })

            $(document).on('change keyup', '.climate-zone, .building-classification, .window-properties, table input', function () {

            })
        })
    </script>
@endsection
